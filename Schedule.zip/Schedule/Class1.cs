﻿using FluentScheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedule
{
    public class MyRegistry : Registry
    {
        public MyRegistry()
        {
            Action someMethod = new Action(() =>
            {
                Console.WriteLine($"Calling to the server at {DateTime.Now}");
            });

            // Schedule schedule = new Schedule(someMethod);
            // schedule.ToRunNow();

            this.Schedule(someMethod).ToRunNow();
            this.Schedule(someMethod).ToRunEvery(15).Seconds();
        }
    }
}
