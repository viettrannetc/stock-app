﻿using FluentScheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedule
{
    /// <summary>
    /// https://stackoverflow.com/questions/42978573/how-to-use-fluentscheduler-library-to-schedule-tasks-in-c
    /// </summary>
    public class MyRegistry : Registry
    {
        /// <summary>
        /// https://localhost:44359/StockPattern/Pattern?code=&startFrom=2021-3-01&soPhienGd=5&trungbinhGd=50&toDate=2021-5-31
        /// </summary>
        private string _nameUrl = @"https://localhost:44359/StockPattern/Pattern100K?code=&startFrom={0}&soPhienGd=5&trungbinhGd=50&toDate={1}";
        public MyRegistry()
        {
            Action someMethod = new Action(async () =>
            {
                var restService = new RestServiceHelper();
                var year = 2021;
                for (int i = 1; i <= 12; i++)
                {
                    var daysInMonth = DateTime.DaysInMonth(year, i);
                    var fromDate = new DateTime(year, i, 1);
                    var toDate = new DateTime(year, i, daysInMonth);

                    var url = string.Format(_nameUrl, fromDate, toDate);
                    
                    var result = await restService.Get<bool>(url);
                }


            });

            // Schedule schedule = new Schedule(someMethod);
            // schedule.ToRunNow();

            this.Schedule(someMethod).ToRunOnceAt(DateTime.Now.AddSeconds(30));
        }
    }
}
