﻿// See https://aka.ms/new-console-template for more information

//Console.WriteLine("Hello, World!");

using FluentScheduler;
using Schedule;

//JobManager.Initialize();

//JobManager.AddJob(
//    () => Console.WriteLine("15 second just passed."),
//    s => s.ToRunEvery(15).Seconds()
//);

JobManager.Initialize(new MyRegistry());
Console.ReadLine();