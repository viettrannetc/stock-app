﻿// See https://aka.ms/new-console-template for more information
using FluentScheduler;
using Schedule;
using System;

//https://fluentscheduler.github.io/
JobManager.Initialize(new MyRegistry());
Console.ReadLine();